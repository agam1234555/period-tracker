# Backup reminder patch (Stage 2, step 2)
Applies on top of the backup/restore patch. No App.tsx change.

Copy into your project (same paths):
- src/backupReminder.ts, src/backupReminder.test.ts   (new)
- src/ui/BackupPanel.tsx                               (replaces the previous version)
- src/db.ts                                            (adds getLastBackupAt / setLastBackupAt at the end;
                                                        if you have edited db.ts, paste just those two functions)

Append to src/index.css:

    .warn { background: #f5a62326; border-left: 3px solid #f5a623; padding: 6px 10px; margin: 8px 0; border-radius: 6px; font-size: .85rem; }

Then: npm test && npm run build
Expected: 136 existing + 9 new = 145 tests.
