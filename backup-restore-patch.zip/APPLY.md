# Backup / restore patch (Stage 2, step 1)

Copy these into your project (same paths):
- src/backup.ts, src/backup.test.ts, src/ui/BackupPanel.tsx  (new)
- src/db.ts  (only change: `replaceAllDays()` appended at the end; skip the copy and just paste that function if you have edited db.ts)

Then make TWO edits in src/App.tsx (not shipped, because your App.tsx has the date-rollover changes):

1. With the other UI imports:
       import { BackupPanel } from './ui/BackupPanel'
2. After the <DayEditor ... /> line, inside <main>:
       <BackupPanel onRestored={() => setLast(null)} />

(onRestored clears the one-level undo so Undo can't write a pre-restore value back.)

Then: npm test && npm run build
Expected on the pre-rollover baseline: 130 tests. On your project it should be 125 + 11 = 136.
