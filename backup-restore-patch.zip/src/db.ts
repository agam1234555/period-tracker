// IndexedDB storage via Dexie. All data stays on the device.
import Dexie, { type EntityTable } from 'dexie'
import type { DayRecord, Days } from './engine/analyze'

export interface DayRow extends DayRecord {
  date: string // 'YYYY-MM-DD' (primary key)
}
export interface MetaRow {
  key: string
  value: unknown
}

export const db = new Dexie('cycle') as Dexie & {
  days: EntityTable<DayRow, 'date'>
  meta: EntityTable<MetaRow, 'key'>
}
db.version(1).stores({ days: 'date', meta: 'key' })

export async function loadDays(): Promise<Days> {
  const out: Days = {}
  for (const { date, ...rest } of await db.days.toArray()) out[date] = rest
  return out
}

/** Save one day. An empty record (no fields set) deletes the row. */
export async function saveDay(date: string, rec: DayRecord): Promise<void> {
  const clean = Object.fromEntries(Object.entries(rec).filter(([, v]) => v !== undefined && v !== null && v !== false && v !== 0 && v !== ''))
  if (Object.keys(clean).length === 0) await db.days.delete(date)
  else await db.days.put({ ...clean, date })
}

/** Replace ALL stored days with `days`. One transaction: if anything fails, the old data is kept. */
export async function replaceAllDays(days: Days): Promise<void> {
  const rows: DayRow[] = Object.entries(days).map(([date, rec]) => ({ ...rec, date }))
  await db.transaction('rw', db.days, async () => {
    await db.days.clear()
    await db.days.bulkPut(rows)
  })
}
