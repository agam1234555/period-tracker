# Cycle history patch
Applies on top of the project after first-run-setup (248 tests). No engine / db changes.

NEW:      src/history.ts, src/history.test.ts, src/ui/HistoryCard.tsx
REPLACE:  src/App.tsx   <-- DIFF FIRST. Only 4 changes vs the first-run-setup App.tsx:
            imports computeHistory + HistoryCard, a `history` useMemo, and the Insights tab now renders <HistoryCard/> above <InsightsCard/>
CSS:      append index.css.append.txt to the bottom of src/index.css

Then: npm test && npm run build
Expected: 248 + 12 new = 260 tests, clean build, 1 known lint warning.
