# Everyday-UI patch: simpler day editor, calendar markers, clearer forecast wording, phone polish
Applies on top of the project at 203 tests. No engine, App.tsx or db.ts changes.

NEW:      src/ui/dayMarks.ts, src/ui/dayMarks.test.ts, src/ui/forecastText.ts, src/ui/forecastText.test.ts
REPLACE:  src/ui/DayEditor.tsx, src/ui/Calendar.tsx, src/ui/ForecastCard.tsx,
          src/symptoms.ts, src/symptoms.test.ts   (adds symptomSummary + 4 tests), README.md

CSS (src/index.css):
  1. DELETE the old `.dot { ... }` rule (one line; the new markers replace it).
  2. APPEND the entire contents of index.css.append.txt to the bottom.

Then: npm test && npm run build
Expected: 203 + 21 new = 224 tests, clean build, same single known lint warning.
