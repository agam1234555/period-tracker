# First-run setup patch
Applies on top of the project after native-feel + insights-wording-fix (235 tests). No engine / db changes.

NEW:      src/setup.ts, src/setup.test.ts, src/ui/SetupCard.tsx
REPLACE:  src/App.tsx   <-- DIFF FIRST. Only 3 changes vs the native-feel App.tsx:
            1. imports SetupCard
            2. reads days via `loaded` (undefined while loading) so existing users never see the setup card flash
            3. Today tab shows <SetupCard/> instead of the empty forecast card when nothing is logged and it was not skipped
CSS:      append index.css.append.txt to the bottom of src/index.css

Then: npm test && npm run build
Expected: 235 + 13 new = 248 tests, clean build, 1 known lint warning.
