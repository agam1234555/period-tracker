# Insights patch (Stage 2, step 4)
Applies on top of the symptoms + mood patch.

New files (same paths): src/insights.ts, src/insights.test.ts, src/ui/InsightsCard.tsx

Edit src/App.tsx (3 small additions):
1. With the other imports:
       import { InsightsCard } from './ui/InsightsCard'
       import { computeInsights } from './insights'
2. After the `const f = useMemo(...)` line:
       const insights = useMemo(() => computeInsights(days), [days])
3. In the JSX, between <DayEditor ... /> and <BackupPanel ... />:
       <InsightsCard insights={insights} />

Append to src/index.css:

    .ins { margin: 6px 0 10px; padding-left: 1.1rem; font-size: .9rem; }
    .ins li { margin: 4px 0; }

Then: npm test && npm run build
Expected: 157 existing + 17 new = 174 tests.
