# Insights wording fix
Replace: src/insights.ts, src/insights.test.ts, src/ui/InsightsCard.tsx
- "Cramps clusters" grammar bug: new wording has no verb that must agree with the symptom name
- removed the card label that repeated the page title "Insights"
Then: npm test && npm run build  -> expected 233 + 2 new = 235 tests (if you already applied everything up to native-feel).
