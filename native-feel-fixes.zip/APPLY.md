# Native-feel fixes (only if you already applied native-feel-ui-patch)
Replace: src/ui/Sheet.tsx, src/ui/Calendar.tsx, src/index.css
- calendar cells now ~45px on a 390px phone (were ~43px)
- sheet returns focus to the tapped day when it closes
- tab labels 12px (were 11px)
Then: npm test && npm run build  -> still 233 tests.
- legend: each marker now stays with its own label (no wrapped/orphaned marker, no indented second row)
