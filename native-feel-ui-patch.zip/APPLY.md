# Native-feel UI patch: bottom tabs, bottom-sheet day editor, switches, dark mode, swipe, haptics
Applies on top of the project at 224 tests (after everyday-ui-patch). No engine / db / logic changes.

NEW:      src/ui/tabs.ts, src/ui/TabBar.tsx, src/ui/Icons.tsx, src/ui/Sheet.tsx,
          src/ui/haptics.ts, src/ui/haptics.test.ts, src/ui/swipe.ts, src/ui/swipe.test.ts
REPLACE:  src/ui/Chip.tsx, src/ui/PeriodBar.tsx, src/ui/DayEditor.tsx, src/ui/Calendar.tsx
REPLACE:  src/App.tsx    <-- DIFF FIRST. It keeps your rollover (./ui/today) and all features; layout is now tabs.
REPLACE:  src/index.css  <-- whole file (new design tokens, dark mode). Any custom CSS you added yourself would be lost.
REPLACE:  index.html     <-- project root (adds viewport-fit=cover, dark theme colour, iOS web-app meta)

Then: npm test && npm run build
Expected: 224 + 9 new = 233 tests, clean build, 1 known lint warning (set-state-in-effect in DayEditor).
