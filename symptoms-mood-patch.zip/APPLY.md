# Symptoms + mood patch (Stage 2, step 3)
Applies on top of the backup/restore and backup-reminder patches. No App.tsx change.

Copy into your project (same paths):
- NEW:      src/symptoms.ts, src/symptoms.test.ts, src/ui/Chip.tsx, src/ui/SymptomPicker.tsx
- REPLACE:  src/backup.ts, src/backup.test.ts   (format v2; v1 files still restore)
            src/ui/DayEditor.tsx                (adds the picker; flow chips now use the same toggle)
            src/db.ts                           (saveDay also drops empty arrays; if you edited db.ts, change only that one filter)

Edit src/engine/analyze.ts: in `interface DayRecord`, add these two lines (type-only; no model logic changes):

    s?: string[] // symptom keys (see symptoms.ts); display / insights only
    m?: 1 | 2 | 3 | 4 | 5 // mood; display / insights only

Append to src/index.css:

    .picker { margin: 10px 0; }
    .group { display: flex; flex-wrap: wrap; gap: 8px; margin: 6px 0 12px; }
    .chip.tog { display: inline-flex; align-items: center; gap: 6px; min-height: 40px; padding: 6px 14px; font-size: .95rem; }
    .chip.tog .tick { display: inline-block; min-width: 1.1em; text-align: center; }
    .chip.tog:disabled { opacity: .45; cursor: not-allowed; }
    .chip.tog:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }

Then: npm test && npm run build
Expected: 145 existing + 12 new = 157 tests.
